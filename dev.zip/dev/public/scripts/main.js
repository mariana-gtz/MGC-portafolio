//Global variables
const db = firebase.firestore();
const storage = firebase.storage();


let storageRef = storage.ref();

let btnsImgs;


// Get the container element
let btnContainer = document.getElementById("btn-row");

// Get all buttons with class="btn-proyecto" inside the container
let btns = btnContainer.getElementsByClassName("btn-proyecto");

// Loop through the buttons and add the active class to the current/clicked button
for (let i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function () {
    let current = document.getElementsByClassName("btn-active");
    current[0].className = current[0].className.replace(" btn-active", "");
    this.className += " btn-active";
  });
}

//Showing all projects
document.getElementById("btn-todos").onclick = function () {
  let all = document.querySelectorAll(".proyecto");
  for (let i = 0; i < all.length; i++) {
    all[i].style.display = "block";
  }
};

//Showing programming projects
document.getElementById("btn-programacion").onclick = function () {
  let all = document.querySelectorAll(".proyecto");
  for (let i = 0; i < all.length; i++) {
    if (all[i].classList.contains("programacion")) {
      all[i].style.display = "block";
    } else {
      all[i].style.display = "none";
    }
  }
};

//Showing develpoment projects
document.getElementById("btn-desarrollo").onclick = function () {
  let all = document.querySelectorAll(".proyecto");
  for (let i = 0; i < all.length; i++) {
    if (all[i].classList.contains("desarrollo")) {
      all[i].style.display = "block";
    } else {
      all[i].style.display = "none";
    }
  }
};

//Showing design projects
document.getElementById("btn-diseno").onclick = function () {
  let all = document.querySelectorAll(".proyecto");
  for (let i = 0; i < all.length; i++) {
    if (all[i].classList.contains("diseno")) {
      all[i].style.display = "block";
    } else {
      all[i].style.display = "none";
    }
  }
};

function sendData(id)  {
  return db.collection('projects').doc(id).get().then(function(doc) {
    if (doc.exists) {
        console.log("Document data:", doc.data());
        sessionStorage.setItem('p-name', doc.data().name);
        sessionStorage.setItem('p-description', doc.data().description);
        sessionStorage.setItem('p-category', doc.data().category);
        sessionStorage.setItem('p-image', doc.data().image);
        //return 1;
    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
        //return 0;
    }
  }).catch(function(error) {
    console.log("Error getting document:", error);
    //return 0;
  });
  
}

//Getting projects on callback
const onGetProjects = (callback) => db.collection('projects').onSnapshot(callback);


//Refreshing window when data is modified
window.addEventListener('DOMContentLoaded', async(e) =>{

  onGetProjects((querySnapshot) => {
      //document.getElementById("log-proyectos").innerHTML="";
      //const querySnapshot = await getProjects();
      querySnapshot.forEach(doc =>{
          
          
          //Obtiene todos los proyectos en la BD
          const project = doc.data();
          project.id    = doc.id;
          
          document.getElementById("log-proyectos").innerHTML += `<div class="column col-xl-5 col-md-8 col-sm-8 ${project.category} proyecto">
                                                                      
                                                                          <figure class="effect-steve">
                                                                              <img class="img-fluid img-project" src="${project.image}" data-id="${project.id}" />
                                                                              <figcaption>
                                                                                  <h2>${project.name}</h2>
                                                                              </figcaption>
                                                                          </figure>
                                                                  </div>`;
          
        });
        btnsImgs = document.querySelectorAll('.img-project');
        console.log(btnsImgs);

        //Detectando evento click de cada proyecto para más info
        btnsImgs.forEach(btn => {
          btn.addEventListener('click',  async (e) => {
            await sendData(e.target.dataset.id);
            window.document.location = './projects/new.html'
          });
        });
  });
});

// onclick="await sendData('${project.id}')"


