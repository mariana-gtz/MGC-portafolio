//Global variables
const db = firebase.firestore();
const storage = firebase.storage();


let storageRef = storage.ref();



//Refreshing window when data is modified
window.addEventListener('DOMContentLoaded', (e) =>{

  document.getElementById("txt-title").textContent       = sessionStorage.getItem('p-name');                
  document.getElementById("img-project").src             = sessionStorage.getItem('p-image');              
  document.getElementById("txt-description").textContent = sessionStorage.getItem('p-description'); 
 
  if(sessionStorage.getItem('p-category')==="diseno"){
      document.getElementById("txt-category").textContent = "Diseño";
  } else if (sessionStorage.getItem('p-category')==="programacion") {
      document.getElementById("txt-category").textContent = "Programación";
  } else{
      document.getElementById("txt-category").textContent = "Desarrollo";
  }

  sessionStorage.clear();
});