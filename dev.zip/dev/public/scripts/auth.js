//Make AUTH reference
const auth = firebase.auth();

//Forms
const loginForm    = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");

//Buttons
const btnRegister  = document.getElementById("btn-R");
const btnLogin     = document.getElementById("btn-LI");
const btnModal     = document.getElementById("btn-auth");
const logout       = document.getElementById("logout");

//Error messages
let errorLI = document.getElementById("validation-LI");
let errorR  = document.getElementById("validation-R");

//Modal
const modalLIR = document.getElementById("modalAuth");

//CRUD Menu
let crudNav = document.getElementById("crud-nav");

//UI loading
btnModal.style.display = 'none';
logout.style.display   = 'none';


const setupUI = (user, checked) => {
    if (user){
        //Toggle UI element
        if(checked){
            crudNav.style.display  = 'block';
        }
        logout.style.display   = 'inline-block';
        btnModal.style.display = 'none';
    } else{
        //Toggle UI element
        crudNav.style.display  = 'none';
        logout.style.display   = 'none';
        btnModal.style.display = 'inline-block';
    }
}


//Listen for auth status changes. If no one is logged in, user=null. Else, user=logged in user.
auth.onAuthStateChanged(user => {
    if(user){
        //User logged in
        console.log("logged in", user.uid);
        if(user.uid === "MLszkURnTOcqfz4U1gXil829vrz2"){
            setupUI(user,true);
        }else{
            if(window.location.href === "https://mariana-gutierrez.web.app/pages/crud.html"){
                window.location.href="https://mariana-gutierrez.web.app/pages/404.html"
            }
            setupUI(user, false);
        }
    } else{
        //User logged out
        console.log("logged out");
        if(window.location.href === "https://mariana-gutierrez.web.app/pages/crud.html"){
            window.location.href="https://mariana-gutierrez.web.app/pages/404.html"
        }
        setupUI();
    }
});

//Open modal
btnModal.addEventListener("click", (e) => {
    cleanFields();
});

//Login method
loginForm.addEventListener("submit", (e) => {
    e.preventDefault();

    //Get user info
    const email = loginForm["email-LI"];
    const pwd   = loginForm["psw-LI"];

    //Validate fields
    if(email.value != '' && pwd.value.length >= 6 ){
        //Login user
        auth.signInWithEmailAndPassword(email.value, pwd.value).catch(function(error)  {
            alert( "Error. Correo/contraseña incorrecto(s).");

        });
        //Close modal
        $(modalLIR).modal('hide');
    }
    else{
        if((pwd.value.length < 6 && pwd.value.length > 0)){
            errorLI.innerHTML = "Recuerda que la contraseña debe ser de al menos 6 caracteres.";
        }
        else{
            errorLI.innerHTML = "Favor de llenar los campos obligatorios (*).";
        }
    }


});

//Signup method
registerForm.addEventListener("submit", (e) =>{
     e.preventDefault();

    //Get user info
    const email = registerForm["email-R"];
    const pwd   = registerForm["psw-R"];
    const pwd2  = registerForm["psw2-R"];

    //Validate fields
    if(email.value != '' && pwd.value.length >= 6  && pwd2.value.length >= 6){
        //Validate passwords match
        if(pwd.value === pwd2.value){
            
            //Signup user
            auth.createUserWithEmailAndPassword(email.value, pwd.value).catch(function(error)  {
                alert( "Error. Usuario actualmente existente.");
            });

            //Close modal
            $(modalLIR).modal('hide');
        }
        else{
            errorR.innerHTML = "Las contraseñas ingresadas no coinciden. Favor de verificarlas."
        }
    }
    else{
        if((pwd.value.length < 6 && pwd.value.length > 0) || (pwd2.value.length > 0 && pwd2.value.length < 6)){
            errorR.innerHTML = "Recuerda que la contraseña debe ser de al menos 6 caracteres.";
        }
        else{
            errorR.innerHTML = "Favor de llenar los campos obligatorios (*).";
        }
    }
});


//Logout method
logout.addEventListener('click', (e) => {
    auth.signOut();
});

//Modal tabs behaviour
$(".tabs").on('click', function(){
    cleanFields();
    $(".tabs").removeClass("active");
    $(".tabs h6").removeClass("font-weight-bold");
    $(".tabs h6").addClass("text-muted");
    $(this).children("h6").removeClass("text-muted");
    $(this).children("h6").addClass("font-weight-bold");
    $(this).addClass("active");
    
    current_fs = $(".active");
    
    next_fs = $(this).attr('id');
    next_fs = "#" + next_fs + "1";
    
    $("fieldset").removeClass("show");
    $(next_fs).addClass("show");
    
    current_fs.animate({}, {
        step: function() {
        current_fs.css({
            'display': 'none',
            'position': 'relative'
        });
        next_fs.css({
            'display': 'block'
        });
        }
    });
});

//Clean forms
function cleanFields() {
    errorLI.innerHTML = '';
    errorR.innerHTML  = '';
    loginForm.reset();
    registerForm.reset();
}


    



