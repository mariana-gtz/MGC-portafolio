//Global variables
const db = firebase.firestore();

const storage = firebase.storage();
const projectForm = document.getElementById("add-form");


let storageRef = storage.ref();
let editStatus = false;
let editID='';
let imageURL;

//Initializing DataTable
let table = $('#tbl-projects').DataTable({
    "pageLength": 1,
    "iDisplayLength": 1,
    "aLengthMenu": [[1, 2, 4, 6, -1], [1, 2, 4, 8, "All"]],
    "language": {
        "lengthMenu": "Mostrar _MENU_ registros",
        "zeroRecords": "Sin resultados encontrados",
        "info": "Página _PAGE_ de _PAGES_",
        "infoEmpty": "Registros no disponibles",
        "infoFiltered": "(Filtrado de _MAX_ registros totales)",
        "decimal":        "",
        "emptyTable":     "No hay registros disponibles",
        "loadingRecords": "Cargando...",
        "processing":     "Procesando...",
        "search":         "Buscar:",
        "paginate": {
            "first":      "Primera",
            "last":       "Última",
            "next":       "Siguiente",
            "previous":   "Anterior"
        },
        "aria": {
            "sortAscending":  ": ordenar la columna de forma ascendente",
            "sortDescending": ": aordenar la columna de forma descendente"
        }
    },
    "scrollX": true,
    "responsive": true,
    "columnDefs": [{
        targets: -1, //-1 es la ultima columna y 0 la primera
        data: null,
        orderable: false,
        defaultContent: `<div class="text-center btn-group" style="margin-left:20px;">  
                            <button type="button" class="btn btn-edit btn-xs dt-edit">
                                <span class="fa fa-pencil" aria-hidden="true"></span>
                            </button>
                            <button type="button" class="btn btn-delete btn-xs dt-delete" > 
                                <span class="fa fa-trash" aria-hidden="true"></span>
                            </button>
                        </div>`
    },{
        targets: [0],
        visible: false,
        searchable: false
    },{
        targets : [4],
        orderable:false,
        'render': function (data, type, full, meta) {
            return '<img src="'+ data +'" style="width:80px"/>';
        }
    },{
        targets: [2],
        render: function (data, type, full, meta) {
            return "<div class='text-wrap'>" + data + "</div>";
        }
    }]
} );

//Getting projects on callback
const onGetProjects = (callback) => db.collection('projects').onSnapshot(callback);

//Saving project on Firestore
function saveProject(name, description, category, image){
     return db.collection('projects').doc().set({
        name,
        description,
        category,
        image
    });
}

//Deleting a project on Firestore
function deleteProject(id){
    //Delete Storage File
    db.collection('projects').doc(id).delete();
};

//Updating a project on Firestore
function updateProject(id, updatedProject){
    return db.collection('projects').doc(id).update(updatedProject);
}

//Upload image to Firebase Cloud Storage
async function saveImage(){
    imageURL='';

    const file = document.getElementById('img-upload').files[0];

    const name = new Date() + '-' + file.name;

    const metadata = {
        contentType : file.type
    };

    const uploadTask = storageRef.child(name).put(file, metadata);

    uploadTask
    .then(snapshot => snapshot.ref.getDownloadURL())
    .then(downloadURL => {
        imageURL = downloadURL;
    })

    return imageURL;
};

//Getting a list of all projects on Firestore
function getProjects(){
    return db.collection('projects').get();
}

//Refreshing window when data is modified
window.addEventListener('DOMContentLoaded', async(e) =>{

    onGetProjects((querySnapshot) => {
        table.clear();
        table.draw();
        //const querySnapshot = await getProjects();
        querySnapshot.forEach(doc =>{
            
            
            //Obtiene todos los proyectos en la BD
            const project = doc.data();
            project.id    = doc.id;
            
            console.log(project);
            
            //Añade fila por cada proyecto
            addRow(project.id,project.name, project.description, project.category, project.image);
        });
        
    });
});

//Deleting a project
$('#tbl-projects').on('click', 'tbody .btn-delete', function () {
    var data_row = table.row($(this).closest('tr')).data();
    console.log(data_row[0]);
    deleteProject(data_row[0]);
});

//Updating a project (open update modal)
$('#tbl-projects').on('click', 'tbody .btn-edit', function () {
    editID='';
    editStatus = true;

    let data_row = table.row($(this).closest('tr')).data();
    console.log(data_row);
    
    editID    = data_row[0];
    imageURL  = data_row[4];

    document.getElementById("validation").innerHTML="";
    document.querySelector("h4").innerHTML="Modificar proyecto";
    $('#mdl-projects').modal('show');

    projectForm['project-name'].value = data_row[1];
    projectForm['description'].value  = data_row[2];
    projectForm['category'].value     = data_row[3];
    projectForm['output'].src         = data_row[4];

    document.querySelector(".custom-file-label").innerHTML = "Elige nueva imagen";
});


//Add row to datatable
function addRow(id, name, description, category, image){
    table.row.add([id, name, description, category, image]).draw();
};

//Open the 'add modal'
document.getElementById("btn-add").onclick = function(){
    projectForm.reset();
    document.getElementById('output').src='';
    document.querySelector("h4").innerHTML="Añadir proyecto";
    document.querySelector(".custom-file-label").innerHTML = "Elige la imagen de lista *";
};

//Adding, editing a project
document.getElementById("btn-send").onclick = async function(){

    let formFilled = validateForm();
    const name        = projectForm['project-name'];
    const description = projectForm['description'];
    const category    = projectForm['category'];
    const image       = imageURL;

    if(formFilled){
        if(!editStatus){
            await saveProject(name.value , description.value, category.value, image);
            //Close modal
            $('#mdl-projects').modal('hide');
    
            alert("El proyecto ha sido añadido con éxito");
        }
        else{
            console.log("estoy editando")
            await updateProject(editID,{
                name : name.value,
                description : description.value,
                category: category. value,
                image: imageURL
            });
            //Close modal
            $('#mdl-projects').modal('hide');
        
            alert("El proyecto ha sido modificado con éxito");
        }

    }
};

//Form field validation when adding a project
function validateForm() {
    let name = document.forms["add-form"]["project-name"].value;
    let desc = document.forms["add-form"]["description"].value;
    let cat  = document.forms["add-form"]["category"].value;
    let img  = document.forms["add-form"]["img-upload"].value;

    if ((name === "" || desc==="" || cat==="0" || img ==="") && !editStatus) {
        document.getElementById("validation").innerHTML="Favor de llenar los campos obligatorios (*)";
        return false
    }
    else if(editStatus){
        if ((name === "" || desc==="" || cat==="0")) {
            document.getElementById("validation").innerHTML="Favor de llenar los campos obligatorios (*)";
            return false
        }
        else{
            return true;
        }
    }
    else{
        return true;
    }
};

// Add the following code if you want the name of the file appear on select
$(".custom-file-input").on("change", async function() {
    await saveImage();
    var fileName = $(this).val().split("\\").pop();
    $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
    let image = document.getElementById('output');
    image.src = URL.createObjectURL(event.target.files[0]);
});


//DELETE ON FIRESTORE ELEMENTS THAT ARE NOT ON USE ANYMORE